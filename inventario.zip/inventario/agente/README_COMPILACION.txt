COMPILACION DEL AGENTE SEDUC
============================

El agente se desarrolla en Python, pero se distribuye a usuarios finales solo
como ejecutable Windows.

Para generar el ejecutable, entrar a la carpeta:

  inventario/agente/

y ejecutar:

  compilar_exe.bat

Requisito: tener instalado Python 3 para Windows y disponible como python o
py -3. Si Windows abre el alias de Microsoft Store en vez de Python, instalar
Python desde python.org o corregir el PATH antes de compilar.

El archivo BAT limpia compilaciones anteriores, instala o actualiza
PyInstaller, compila el agente y copia el resultado final desde:

  inventario/agente/dist/seduc_inventario_agent.exe

hacia:

  inventario/agente/seduc_inventario_agent.exe

Al terminar, verificar que exista:

  inventario/agente/seduc_inventario_agent.exe

Ese archivo debe subirse al servidor junto al modulo Inventario.

El boton Descargar Agente usa exclusivamente ese ejecutable desde:

  inventario/ajax/descargar_agente.php

No se debe publicar ni descargar seduc_inventario_agent.py para usuarios
finales.
