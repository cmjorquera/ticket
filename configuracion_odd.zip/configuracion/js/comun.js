function configuracionUrl(ruta) {
    const raiz = typeof window.CONFIG_RELATIVE_ROOT === 'string' ? window.CONFIG_RELATIVE_ROOT : '../';
    return raiz + ruta.replace(/^\/+/, '');
}

function mostrarConfirmacionConfiguracion(titulo, mensaje, onClose) {
    return Swal.fire({
        title: `<div class="alert alert-dark" role="alert">${titulo}</div>`,
        text: mensaje || '',
        width: '570px',
        padding: '40px',
        icon: 'success',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        customClass: {
            popup: 'cuerpo_modal_guardar'
        },
        willClose: () => {
            if (typeof onClose === 'function') {
                onClose();
            }
        }
    });
}

function agregarUsuario(opts) {
    // Guard: se invoca como agregarUsuario() desde el HTML (sin args) y también
    // como agregarUsuario({colegioId, esAdminColegio, nomColegio}) desde el flujo
    // "asignar admin de colegio".
    if (!opts || typeof opts !== 'object' || opts.nodeType || opts.target || opts.originalEvent) {
        opts = {};
    }

    $.ajax({
        url: configuracionUrl('modelos/rescatar/area_trabajo.php'),
        type: 'GET',
        dataType: 'json',
        success: function (areas) {
            $.ajax({
                url: configuracionUrl('modelos/rescatar/colegio.php'),
                type: 'GET',
                dataType: 'json',
                success: function (colegios) {
                    $.ajax({
                        url: configuracionUrl('modelos/rescatar/menu_1.php'),
                        type: 'GET',
                        dataType: 'json',
                        success: function (menus) {
                            const menusObligatorios = [8, 3];
                            let optionsHtml = '<option value="">Seleccione Área de Trabajo</option>';
                            let colegiosHtml = '<option value="">Seleccione Colegio</option>';
                            areas.forEach(area => {
                                optionsHtml += `<option value="${area.id}">${area.nombre_area}</option>`;
                            });
                            colegios.forEach(colegio => {
                                colegiosHtml += `<option value="${colegio.id}">${colegio.nombre}</option>`;
                            });

                            let menusHtml = '';
                            menus.forEach(menu => {
                                const idMenu = parseInt(menu.id_menu, 10);
                                const esObligatorio = menusObligatorios.includes(idMenu);
                                const checked = esObligatorio ? 'checked' : '';
                                const disabled = esObligatorio ? 'disabled' : '';
                                const fixed = esObligatorio ? '<span class="menu-badge-obligatorio">Obligatorio</span>' : '';

                                menusHtml += `
                                    <div class="menu-item-disponible ${esObligatorio ? 'menu-item-obligatorio' : ''}">
                                        <input class="form-check-input menu-checkbox" type="checkbox" value="${menu.id_menu}" id="menu_${menu.id_menu}" ${checked} ${disabled}>
                                        <label class="form-check-label" for="menu_${menu.id_menu}">
                                            ${menu.nombre} ${fixed}
                                        </label>
                                    </div>
                                `;
                            });

                    Swal.fire({
                        title: '',
                        html: `
                                <div class="swal-usuario">
                                    <style>
                                        /* ── Layout principal: 2 columnas ── */
                                        .swal-usuario { text-align: left; color: #1f2a44; }
                                        .swal-usuario__inner { display: flex; gap: 1.2rem; align-items: flex-start; }
                                        .swal-usuario__left  { flex: 0 0 340px; min-width: 0; }
                                        .swal-usuario__right { flex: 1 1 260px; min-width: 220px; display: flex; flex-direction: column; gap: 0; }

                                        /* Cabecera (título + colegio card) */
                                        .swal-usuario__header { display: flex; align-items: center; justify-content: space-between; gap: .8rem; margin-bottom: 1rem; }
                                        .swal-usuario__title { margin: 0; font-size: 1.45rem; font-weight: 800; color: #1c2740; }
                                        .swal-usuario__college-card { display: flex; align-items: center; gap: .6rem; padding: .55rem .75rem; border: 1px solid #d9e4f2; border-radius: 14px; background: #f5f9ff; box-shadow: 0 4px 12px rgba(31,69,123,.07); min-width: 160px; }
                                        .swal-usuario__college-logo, .swal-usuario__college-fallback { width: 40px; height: 40px; border-radius: 10px; display: inline-flex; align-items: center; justify-content: center; border: 1px solid #d7e1ee; background: #fff; flex-shrink: 0; }
                                        .swal-usuario__college-logo { object-fit: contain; padding: 4px; }
                                        .swal-usuario__college-fallback { font-weight: 800; color: #31527d; background: #edf4fb; font-size: .75rem; }
                                        .swal-usuario__college-name { font-size: .82rem; font-weight: 800; color: #1e2d47; line-height: 1.2; }
                                        .swal-usuario__college-meta { color: #6c7b91; font-size: .73rem; margin-top: .1rem; }

                                        /* Formulario izquierda */
                                        .swal-usuario__grid { display: grid; grid-template-columns: 1fr 1fr; gap: .55rem .8rem; }
                                        .swal-usuario__field { display: grid; gap: .2rem; }
                                        .swal-usuario__field--full { grid-column: 1 / -1; }
                                        .swal-usuario__label { font-size: .78rem; font-weight: 700; color: #1f2a44; margin-bottom: 0; text-transform: uppercase; letter-spacing: .03em; }
                                        .swal-usuario__input, .swal-usuario__select { width: 100%; height: 38px; border-radius: 9px; border: 1px solid #c7d4e5; background: #eef4ff; color: #1f2a44; padding: 0 .75rem; font-size: .85rem; outline: none; transition: border-color .15s, box-shadow .15s, background .15s; }
                                        .swal-usuario__input:focus, .swal-usuario__select:focus { border-color: #4f83ff; box-shadow: 0 0 0 .15rem rgba(79,131,255,.18); background: #f7faff; }
                                        .swal-usuario__input--email { background: #fff; }
                                        .swal-usuario__help  { min-height: 14px; font-size: .78rem; font-weight: 600; }
                                        .swal-usuario__help--ok    { color: #13824c; }
                                        .swal-usuario__help--error { color: #c23a3a; }
                                        .swal-usuario__error { font-size: .76rem; color: #c23a3a; min-height: 14px; }

                                        /* Panel de menús derecha */
                                        .swal-usuario__menu-box { border: 1px solid #d9e4f2; border-radius: 14px; background: #f8fbff; padding: .75rem; height: 100%; box-sizing: border-box; overflow-y: auto; max-height: 420px; }
                                        .swal-usuario__menu-title { font-weight: 800; font-size: .82rem; text-transform: uppercase; letter-spacing: .04em; color: #1f2a44; margin-bottom: .6rem; }
                                        .swal-usuario__menu-list { display: flex; flex-direction: column; gap: .35rem; }
                                        .menu-item-disponible { display: flex; align-items: center; gap: 8px; padding: .45rem .6rem; border: 1px solid #e3e8f0; border-radius: 8px; background: #fff; cursor: pointer; transition: border-color .12s, background .12s; min-height: 36px; }
                                        .menu-item-disponible:hover { border-color: #4e73df; background: #f0f5ff; }
                                        .menu-item-disponible .form-check-input { margin: 0; flex-shrink: 0; cursor: pointer; }
                                        .menu-item-disponible .form-check-label { width: 100%; display: flex; align-items: center; justify-content: space-between; gap: 8px; margin: 0; font-size: .82rem; cursor: pointer; line-height: 1.2; }
                                        .menu-item-obligatorio { border-color: #8bb3ff !important; background: #f0f5ff !important; }
                                        .menu-badge-obligatorio { display: inline-flex; align-items: center; padding: 2px 8px; border-radius: 999px; background: #5f8ee6; color: #fff; font-size: .68rem; font-weight: 700; flex-shrink: 0; }

                                        @media (max-width: 780px) {
                                            .swal-usuario__inner { flex-direction: column; }
                                            .swal-usuario__left, .swal-usuario__right { width: 100%; flex: none; }
                                            .swal-usuario__menu-box { max-height: 260px; }
                                        }
                                    </style>

                                    <!-- Cabecera compacta -->
                                    <div class="swal-usuario__header">
                                        <h2 class="swal-usuario__title">Agregar usuario</h2>
                                        <div class="swal-usuario__college-card">
                                            <img src="${configuracionUrl('img/colegios/colegio_0.png')}" alt="" class="swal-usuario__college-logo" id="colegioResumenLogo"
                                                onerror="this.style.display='none'; document.getElementById('colegioResumenFallback').style.display='inline-flex';">
                                            <span class="swal-usuario__college-fallback" id="colegioResumenFallback" style="display:none;">--</span>
                                            <div>
                                                <div class="swal-usuario__college-name" id="colegioResumenNombre">Selecciona un colegio</div>
                                                <div class="swal-usuario__college-meta" id="colegioResumenMeta">ID colegio: --</div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Dos columnas -->
                                    <div class="swal-usuario__inner">

                                        <!-- IZQ: Formulario -->
                                        <div class="swal-usuario__left">
                                            <form class="swal-usuario__grid" id="usuarioForm">
                                                <div class="swal-usuario__field">
                                                    <label class="swal-usuario__label" for="email">Email</label>
                                                    <input type="email" class="swal-usuario__input swal-usuario__input--email" id="email" placeholder="usuario@correo.cl">
                                                    <div id="emailEstado" class="swal-usuario__help"></div>
                                                    <div id="email-error" class="swal-usuario__error"></div>
                                                </div>
                                                <div class="swal-usuario__field">
                                                    <label class="swal-usuario__label" for="area_trabajo">Departamento</label>
                                                    <select class="swal-usuario__select" id="area_trabajo">${optionsHtml}</select>
                                                    <div id="area_trabajo-error" class="swal-usuario__error"></div>
                                                </div>
                                                <div class="swal-usuario__field">
                                                    <label class="swal-usuario__label" for="nombre">Nombre</label>
                                                    <input type="text" class="swal-usuario__input" id="nombre" placeholder="Nombre">
                                                    <div id="nombre-error" class="swal-usuario__error"></div>
                                                </div>
                                                <div class="swal-usuario__field">
                                                    <label class="swal-usuario__label" for="apellidoPaterno">Apellido paterno</label>
                                                    <input type="text" class="swal-usuario__input" id="apellidoPaterno" placeholder="Apellido paterno">
                                                    <div id="apellidoPaterno-error" class="swal-usuario__error"></div>
                                                </div>
                                                <div class="swal-usuario__field">
                                                    <label class="swal-usuario__label" for="apellidoMaterno">Apellido materno</label>
                                                    <input type="text" class="swal-usuario__input" id="apellidoMaterno" placeholder="Apellido materno">
                                                    <div id="apellidoMaterno-error" class="swal-usuario__error"></div>
                                                </div>
                                                <div class="swal-usuario__field">
                                                    <label class="swal-usuario__label" for="id_colegio">Colegio</label>
                                                    <select class="swal-usuario__select" id="id_colegio">${colegiosHtml}</select>
                                                    <div id="id_colegio-error" class="swal-usuario__error"></div>
                                                </div>
                                                <div class="swal-usuario__field swal-usuario__field--full">
                                                    <label class="swal-usuario__label" for="sexo">Sexo</label>
                                                    <select class="swal-usuario__select" id="sexo">
                                                        <option value="">Seleccione sexo</option>
                                                        <option value="1">Masculino</option>
                                                        <option value="2">Femenino</option>
                                                    </select>
                                                    <div id="sexo-error" class="swal-usuario__error"></div>
                                                </div>
                                            </form>
                                        </div>

                                        <!-- DER: Menús -->
                                        <div class="swal-usuario__right">
                                            <div class="swal-usuario__menu-box">
                                                <div class="swal-usuario__menu-title"><i class="bi bi-grid-3x3-gap-fill me-1"></i>Menús disponibles</div>
                                                <div class="swal-usuario__menu-list">${menusHtml}</div>
                                            </div>
                                        </div>

                                    </div><!-- /inner -->
                                </div>
                            </div>
                            `,
                        showCancelButton: true,
                        width: '860px',
                        padding: '24px',
                        confirmButtonColor: '#0b6aa2',
                        cancelButtonColor: '#e9edf3',
                        confirmButtonText: 'Crear usuario',
                        cancelButtonText: 'Cancelar',
                        customClass: {
                            popup: 'cuerpo_modal_guardar'
                        },
                        preConfirm: () => {
                            const nombre = document.getElementById('nombre');
                            const apellidoPaterno = document.getElementById('apellidoPaterno');
                            const apellidoMaterno = document.getElementById('apellidoMaterno');
                            const email = document.getElementById('email');
                            const areaTrabajo = document.getElementById('area_trabajo');
                            const sexo = document.getElementById('sexo');
                            const idColegio = document.getElementById('id_colegio');
                            const menuIds = Array.from(document.querySelectorAll('.menu-checkbox:checked')).map(item => item.value);

                            if (!menuIds.includes('8')) {
                                menuIds.push('8');
                            }
                            if (!menuIds.includes('3')) {
                                menuIds.push('3');
                            }

                            if (!validarCamposVacios(nombre, apellidoPaterno, email, areaTrabajo, sexo, idColegio)) {
                                Swal.showValidationMessage('Por favor, complete los campos obligatorios en rojo.');
                                return false;
                            }

                            return new Promise((resolve) => {
                                $.ajax({
                                    url: configuracionUrl('modelos/guardar/guardar_usuario.php'),
                                    type: 'POST',
                                    dataType: 'json',
                                    data: {
                                        email: email.value
                                    },
                                    success: function (response) {
                                        if (response.email_exists) {
                                            Swal.showValidationMessage(
                                                `Usuario existe y se llama ${response.email_owner}`
                                            );
                                            resolve(false);
                                        } else {
                                            resolve({
                                                action: 'agregarUsuario',
                                                nombre: nombre.value,
                                                apellidoPaterno: apellidoPaterno.value,
                                                apellidoMaterno: apellidoMaterno.value,
                                                email: email.value,
                                                sexo: sexo.value,
                                                areaTrabajo: areaTrabajo.value,
                                                idColegio: idColegio.value,
                                                menuIds: menuIds,
                                                esAdminColegio: opts.esAdminColegio ? 1 : 0
                                            });
                                        }
                                    },
                                    error: function () {
                                        Swal.showValidationMessage(
                                            'Error al validar los datos. Por favor, intente nuevamente.'
                                        );
                                        resolve(false);
                                    }
                                });
                            });
                        },
                        didOpen: () => {
                            const popup = Swal.getPopup();
                            const emailInput = popup.querySelector('#email');
                            const emailEstado = popup.querySelector('#emailEstado');
                            const colegioSelect = popup.querySelector('#id_colegio');
                            const colegioNombre = popup.querySelector('#colegioResumenNombre');
                            const colegioMeta = popup.querySelector('#colegioResumenMeta');
                            const colegioLogo = popup.querySelector('#colegioResumenLogo');
                            const colegioFallback = popup.querySelector('#colegioResumenFallback');
                            const confirmButton = popup.querySelector('.swal2-confirm');
                            const cancelButton = popup.querySelector('.swal2-cancel');

                            popup.style.borderRadius = '28px';
                            popup.style.boxShadow = '0 28px 60px rgba(20, 42, 82, 0.20)';

                            if (confirmButton) {
                                confirmButton.style.borderRadius = '16px';
                                confirmButton.style.padding = '0.9rem 1.3rem';
                                confirmButton.style.fontWeight = '800';
                            }

                            if (cancelButton) {
                                cancelButton.style.borderRadius = '16px';
                                cancelButton.style.padding = '0.9rem 1.3rem';
                                cancelButton.style.fontWeight = '700';
                                cancelButton.style.color = '#1f2a44';
                            }

                            function actualizarResumenColegio() {
                                const opcion = colegioSelect.options[colegioSelect.selectedIndex];
                                const idColegio = opcion ? opcion.value : '';
                                const nombre = opcion ? opcion.text : 'Selecciona un colegio';

                                colegioNombre.textContent = idColegio ? nombre : 'Selecciona un colegio';
                                colegioMeta.textContent = idColegio ? `ID colegio: ${idColegio}` : 'ID colegio: --';
                                colegioFallback.textContent = idColegio || '--';

                                if (idColegio) {
                                    colegioLogo.style.display = 'inline-flex';
                                    colegioLogo.src = configuracionUrl(`img/colegios/colegio_${idColegio}.png`);
                                    colegioFallback.style.display = 'none';
                                } else {
                                    colegioLogo.style.display = 'none';
                                    colegioFallback.style.display = 'inline-flex';
                                }
                            }

                            let emailValidationRequest = null;
                            function validarEmailDisponibilidad(email) {
                                if (!email) {
                                    emailEstado.textContent = '';
                                    emailEstado.className = 'swal-usuario__help';
                                    return;
                                }

                                if (emailValidationRequest && typeof emailValidationRequest.abort === 'function') {
                                    emailValidationRequest.abort();
                                }

                                emailEstado.textContent = 'Validando correo...';
                                emailEstado.className = 'swal-usuario__help';

                                emailValidationRequest = $.ajax({
                                    url: configuracionUrl('modelos/rescatar/creando_usuario.php'),
                                    type: 'GET',
                                    dataType: 'json',
                                    data: { email },
                                    success: function (response) {
                                        if (response.email_exists) {
                                            emailEstado.textContent = `Usuario existe y se llama ${response.email_owner}`;
                                            emailEstado.className = 'swal-usuario__help swal-usuario__help--error';
                                            Swal.showValidationMessage(`Usuario existe y se llama ${response.email_owner}`);
                                        } else {
                                            emailEstado.textContent = 'Correo disponible.';
                                            emailEstado.className = 'swal-usuario__help swal-usuario__help--ok';
                                            Swal.resetValidationMessage();
                                        }
                                    },
                                    error: function () {
                                        emailEstado.textContent = 'No se pudo validar el correo.';
                                        emailEstado.className = 'swal-usuario__help swal-usuario__help--error';
                                    }
                                });
                            }

                            actualizarResumenColegio();
                            $(colegioSelect).on('change', actualizarResumenColegio);

                            // Flujo "asignar admin de colegio": precargar y bloquear el colegio
                            if (opts.colegioId) {
                                colegioSelect.value = String(opts.colegioId);
                                colegioSelect.setAttribute('disabled', 'disabled');
                                actualizarResumenColegio();

                                const cont = popup.querySelector('.swal-usuario');
                                if (cont && !popup.querySelector('#lu-admin-note')) {
                                    const note = document.createElement('div');
                                    note.id = 'lu-admin-note';
                                    note.className = 'alert alert-info';
                                    note.style.margin = '0 0 12px';
                                    note.innerHTML = '<b>Nota:</b> este usuario quedará como <b>administrador</b> de <b>'
                                        + (opts.nomColegio ? String(opts.nomColegio) : 'el colegio') + '</b> al crearlo.';
                                    cont.insertBefore(note, cont.firstChild);
                                }
                            }

                            $(emailInput).on('blur', function () {
                                validarEmailDisponibilidad($(this).val().trim());
                            }).on('input', function () {
                                emailEstado.textContent = '';
                                emailEstado.className = 'swal-usuario__help';
                                Swal.resetValidationMessage();
                            });
                        }
                    }).then((result) => {
                        if (result.isConfirmed) {
                            const data = result.value;
                            if (data) {
                                $.ajax({
                                    url: configuracionUrl('modelos/guardar/guardar_usuario.php'),
                                    type: 'POST',
                                    data: data,
                                    success: function (response) {
                                        let mensaje = 'Usuario agregado correctamente.';

                                        try {
                                            const respuesta = typeof response === 'string' ? JSON.parse(response) : response;
                                            if (respuesta.message) {
                                                mensaje = respuesta.message;
                                            }
                                        } catch (e) {}

                                        mostrarConfirmacionConfiguracion(
                                            'GUARDADO',
                                            mensaje,
                                            opts.esAdminColegio ? function () { location.reload(); } : undefined
                                        );
                                    },
                                    error: function (xhr, status, error) {
                                        console.error('Error al guardar el usuario:', error);
                                        Swal.fire('Error',
                                            'No se pudo agregar el usuario. Por favor, intente nuevamente.',
                                            'error');
                                    }
                                });
                            }
                        }
                    });
                },
                error: function () {
                    Swal.fire('Error',
                        'No se pudieron cargar los menus disponibles. Por favor, intente nuevamente.',
                        'error');
                }
            });
                },
                error: function () {
                    Swal.fire('Error',
                        'No se pudieron cargar los colegios disponibles. Por favor, intente nuevamente.',
                        'error');
                }
            });
        },
        error: function (xhr, status, error) {
            console.error('Error al obtener las áreas de trabajo:', error);
            Swal.fire('Error',
                'No se pudieron cargar las áreas de trabajo. Por favor, intente nuevamente.',
                'error');
        }
    });
}



function mostrarPermisos(userId) {
    Swal.fire({
        title: '<div class="alert alert-dark" role="alert">PERMISOS PARA EL USUARIO</div>',
        html: '<div id="permisosContent"></div>',
        width: '800px',
        showCancelButton: true,
        confirmButtonColor: '#5B8E4A',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Guardar cambios',
        cancelButtonText: 'Cerrar',
        customClass: {
            popup: 'cuerpo_modal_guardar',
            confirmButton: 'bt_activar_alumno',
            cancelButton: 'bt_activar_alumno'
        },
        preConfirm: () => {
            const permisos = [];
            $('.lock-icon').each(function () {
                const id_menu1 = $(this).attr('id').replace('lockIcon', '');
                const id_tipo_permiso = $(this).hasClass('blue') ? 1 : 3;
                permisos.push({
                    id_menu1,
                    id_tipo_permiso
                });
            });

            return $.ajax({
                url: configuracionUrl('modelos/guardar/guardar_permisos.php'),
                type: 'POST',
                data: {
                    user_id: userId,
                    permisos: JSON.stringify(permisos)
                },
                success: function (response) {
                    console.log("Permisos guardad   os: ", response);
                    mostrarConfirmacionConfiguracion('PERMISOS GUARDADOS', '');
                },
                error: function (xhr, status, error) {
                    console.error("Error al guardar los permisos: ", status, error);
                }
            });
        },
        didOpen: () => {
            $.ajax({
                url: configuracionUrl('modelos/rescatar/menu_1.php'),
                type: 'GET',
                data: {
                    user_id: userId
                },
                success: function (response) {
                    console.log("Respuesta AJAX recibida: ", response);
                    try {
                        var data = JSON.parse(response);
                        var html = `
                                <style>
                                    .submenu-container {
                                        display: flex;
                                        flex-wrap: wrap;
                                    }
                                    .submenu-item {
                                        margin: 10px;
                                        padding: 10px;
                                        border: 1px solid #ccc;
                                        border-radius: 5px;
                                        cursor: pointer;
                                        text-align: center;
                                        transition: transform 0.2s, box-shadow 0.2s;
                                        background-color: white;
                                        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                                    }
                                    .submenu-item.green {
                                        background-color: #90ee90; /* Verde */
                                        color: white;
                                        transform: translateY(-5px);
                                        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
                                    }
                                    .submenu-item.red {
                                        background-color: #F9856C; /* Rojo */
                                        color: white;
                                    }
                                    .lock-icon.red {
                                        color: red; /* Rojo */
                                        font-size: 1.5em; /* Ajusta el tamaño del icono */
                                    }
                                    .lock-icon.blue {
                                        color: #90ee90; /* Azul */
                                        font-size: 1.5em; /* Ajusta el tamaño del icono */
                                    }
                                </style>
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Menú</th>
                                                <th>Submenús</th>
                                                <th>Permiso</th>
                                            </tr>
                                        </thead>
                                        <tbody>`;

                        data.forEach(function (menu) {
                            var submenusHtml = '';
                            if (menu.submenus.length > 0) {
                                submenusHtml += '<div class="submenu-container">';
                                menu.submenus.forEach(function (submenu) {
                                    submenusHtml += `
                                            <div class="submenu-item" onclick="toggleSubmenuColor(this)">
                                                ${submenu.nombre}
                                            </div>`;
                                });
                                submenusHtml += '</div>';
                            }

                            var lockIcon = '';
                            if (menu.id_tipo_permiso == 1) {
                                lockIcon = `<i class="bi bi-unlock lock-icon blue" id="lockIcon${menu.id_menu}" onclick="toggleLock(${menu.id_menu})"></i>`;
                            } else if (menu.id_tipo_permiso == 2 || menu.id_tipo_permiso == 3) {
                                lockIcon = `<i class="bi bi-lock lock-icon red" id="lockIcon${menu.id_menu}" onclick="toggleLock(${menu.id_menu})"></i>`;
                            }

                            html += `
                                    <tr>
                                        <td>${menu.nombre}</td>
                                        <td>${submenusHtml}</td>
                                        <td>${lockIcon}</td>
                                    </tr>`;
                        });

                        html += '</tbody></table></div>';
                        $('#permisosContent').html(html);
                    } catch (e) {
                        console.error("Error al parsear la respuesta: ", e);
                        $('#permisosContent').html('Error al cargar los permisos. Por favor, intente nuevamente.');
                    }
                },
                error: function (xhr, status, error) {
                    console.error("Error AJAX: ", status, error);
                    $('#permisosContent').html('Error al cargar los permisos. Por favor, intente nuevamente.');
                }
            });
        }
    });
}

function estadoUsuario(userId, currentState) {
    if (currentState === 'Activo') {
        openDeactivateModal(userId);
        return;
    }

    openActivateModal(userId);
}

function openActivateModal(userId) {
    Swal.fire({
        title: '<div class="alert alert-dark" role="alert">CONFIRMACION</div>',
        text: '¿Realmente desea activar al usuario?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#5B8E4A',
        cancelButtonColor: '#d33',
        confirmButtonText: 'ACTIVAR',
        cancelButtonText: 'CANCELAR',
        customClass: {
            popup: 'cuerpo_modal_guardar',
            confirmButton: 'bt_activar_alumno',
            cancelButton: 'bt_activar_alumno'
        }
    }).then((result) => {
        if (!result.isConfirmed) {
            return;
        }

        $.ajax({
            url: configuracionUrl('modelos/guardar/guardar_usuario.php'),
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'activarUsuario',
                userId: userId
            },
            success: function (response) {
                if (!response.success) {
                    Swal.fire('Error', response.message || 'No se pudo activar el usuario.', 'error');
                    return;
                }

                mostrarConfirmacionConfiguracion('USUARIO ACTIVADO', response.message || '', function () {
                    location.reload();
                });
            },
            error: function (xhr, status, error) {
                console.error('Error al activar el usuario:', error);
                Swal.fire('Error', 'No se pudo activar el usuario. Por favor, intente nuevamente.', 'error');
            }
        });
    });
}

function openDeactivateModal(userId) {
    $.ajax({
        url: configuracionUrl('modelos/rescatar/razones_bloqueo.php'),
        type: 'GET',
        dataType: 'json',
        success: function (razones) {
            let optionsHtml = '';
            razones.forEach((razon) => {
                optionsHtml += `<option value="${razon.id}">${razon.razon}</option>`;
            });

            Swal.fire({
                title: 'Seleccionar una opción',
                html: `
                    <select id="userSelect" class="swal2-input">
                        ${optionsHtml}
                    </select>
                    <textarea id="userTextarea" class="swal2-textarea" style="display: none;" placeholder="Escribe tu comentario"></textarea>
                `,
                showCancelButton: true,
                confirmButtonColor: '#5B8E4A',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Guardar',
                cancelButtonText: 'Cancelar',
                customClass: {
                    popup: 'cuerpo_modal_guardar',
                    confirmButton: 'bt_activar_alumno',
                    cancelButton: 'bt_activar_alumno'
                },
                preConfirm: () => {
                    const selectedOption = document.getElementById('userSelect').value;
                    const textareaValue = document.getElementById('userTextarea').value;

                    if (selectedOption === 'otra' && !textareaValue) {
                        Swal.showValidationMessage('Es necesario escribir un comentario para esta opción.');
                        return false;
                    }

                    return {
                        selectedOption,
                        textareaValue
                    };
                },
                didOpen: () => {
                    const userSelect = document.getElementById('userSelect');
                    const userTextarea = document.getElementById('userTextarea');
                    userSelect.addEventListener('change', () => {
                        userTextarea.style.display = userSelect.value === 'otra' ? 'block' : 'none';
                    });
                }
            }).then((result) => {
                if (!result.isConfirmed) {
                    return;
                }

                $.ajax({
                    url: configuracionUrl('modelos/guardar/guardar_usuario.php'),
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'bloquearUsuario',
                        userId: userId,
                        selectedOption: result.value.selectedOption,
                        textareaValue: result.value.textareaValue
                    },
                    success: function (response) {
                        if (!response.success) {
                            Swal.fire('Error', response.message || 'No se pudo bloquear el usuario.', 'error');
                            return;
                        }

                        mostrarConfirmacionConfiguracion('USUARIO BLOQUEADO', response.message || '', function () {
                            location.reload();
                        });
                    },
                    error: function (xhr, status, error) {
                        console.error('Error al bloquear el usuario:', error);
                        Swal.fire('Error', 'No se pudieron guardar los datos. Por favor, intente nuevamente.', 'error');
                    }
                });
            });
        },
        error: function (xhr, status, error) {
            console.error('Error al obtener las razones de bloqueo:', error);
            Swal.fire('Error', 'No se pudieron cargar las razones de bloqueo. Por favor, intente nuevamente.', 'error');
        }
    });
}

function modificarUsuario(userId) {
    $.ajax({
        url: configuracionUrl('modelos/rescatar/usuariModificacion.php'),
        type: 'POST',
        dataType: 'json',
        data: { id: userId },
        success: function (data) {
            Swal.fire({
                title: '',
                html: `
                    <div class="swal-usuario">
                        <style>
                            .swal-usuario { text-align: left; color: #1f2a44; }
                            .swal-usuario__header { display: flex; align-items: flex-start; justify-content: space-between; gap: 1.25rem; margin-bottom: 1.35rem; }
                            .swal-usuario__title-wrap { flex: 1 1 auto; padding-top: 0.35rem; }
                            .swal-usuario__title { margin: 0; font-size: 2rem; font-weight: 800; color: #1c2740; text-align: center; }
                            .swal-usuario__college-card { min-width: 240px; max-width: 280px; display: flex; align-items: center; gap: 0.8rem; padding: 0.85rem 1rem; border: 1px solid #d9e4f2; border-radius: 20px; background: linear-gradient(180deg, #ffffff 0%, #f5f9ff 100%); box-shadow: 0 10px 24px rgba(31, 69, 123, 0.08); }
                            .swal-usuario__college-logo, .swal-usuario__college-fallback { width: 54px; height: 54px; border-radius: 16px; display: inline-flex; align-items: center; justify-content: center; border: 1px solid #d7e1ee; background: #fff; flex-shrink: 0; }
                            .swal-usuario__college-logo { object-fit: contain; padding: 5px; }
                            .swal-usuario__college-fallback { font-weight: 800; color: #31527d; background: #edf4fb; }
                            .swal-usuario__college-name { font-size: 1.02rem; font-weight: 800; color: #1e2d47; line-height: 1.2; }
                            .swal-usuario__college-meta { color: #6c7b91; font-size: 0.9rem; margin-top: 0.15rem; }
                            .swal-usuario__grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 0.7rem 0.9rem; }
                            .swal-usuario__field { display: grid; gap: 0.28rem; }
                            .swal-usuario__label { font-size: 0.96rem; font-weight: 800; color: #1f2a44; margin-bottom: 0; }
                            .swal-usuario__input, .swal-usuario__select { width: 100%; min-height: 48px; border-radius: 14px; border: 1px solid #c7d4e5; background: #eef4ff; color: #1f2a44; padding: 0.72rem 0.9rem; font-size: 0.96rem; outline: none; transition: border-color .2s ease, box-shadow .2s ease, background .2s ease; }
                            .swal-usuario__input:focus, .swal-usuario__select:focus { border-color: #4f83ff; box-shadow: 0 0 0 0.18rem rgba(79, 131, 255, 0.16); background: #f7faff; }
                            @media (max-width: 900px) { .swal-usuario__header { flex-direction: column; } .swal-usuario__college-card { max-width: 100%; width: 100%; } .swal-usuario__grid { grid-template-columns: 1fr; } }
                        </style>
                        <div class="swal-usuario__header">
                            <div class="swal-usuario__title-wrap">
                                <h2 class="swal-usuario__title">Modificar usuario</h2>
                            </div>
                            <div class="swal-usuario__college-card">
                                <img src="${configuracionUrl('img/colegios/colegio_0.png')}" alt="" class="swal-usuario__college-logo" id="colegioResumenLogoEditar"
                                    onerror="this.style.display='none'; document.getElementById('colegioResumenFallbackEditar').style.display='inline-flex';">
                                <span class="swal-usuario__college-fallback" id="colegioResumenFallbackEditar" style="display:none;">--</span>
                                <div>
                                    <div class="swal-usuario__college-name" id="colegioResumenNombreEditar">Selecciona un colegio</div>
                                    <div class="swal-usuario__college-meta" id="colegioResumenMetaEditar">ID colegio: --</div>
                                </div>
                            </div>
                        </div>
                        <form class="swal-usuario__grid" id="usuarioForm">
                            <div class="swal-usuario__field">
                                <label class="swal-usuario__label" for="email">Email</label>
                                <input type="email" class="swal-usuario__input" id="email" placeholder="usuario@correo.cl">
                            </div>
                            <div class="swal-usuario__field">
                                <label class="swal-usuario__label" for="area_trabajo">Departamento</label>
                                <select class="swal-usuario__select" id="area_trabajo" name="areaTrabajo">
                                    <option value="">Seleccione Area de Trabajo</option>
                                </select>
                            </div>
                            <div class="swal-usuario__field">
                                <label class="swal-usuario__label" for="nombre">Nombre</label>
                                <input type="text" class="swal-usuario__input" id="nombre" name="nombre" placeholder="Nombre">
                            </div>
                            <div class="swal-usuario__field">
                                <label class="swal-usuario__label" for="apellidoPaterno">Apellido paterno</label>
                                <input type="text" class="swal-usuario__input" id="apellidoPaterno" name="apellidoPaterno" placeholder="Apellido paterno">
                            </div>
                            <div class="swal-usuario__field">
                                <label class="swal-usuario__label" for="apellidoMaterno">Apellido materno</label>
                                <input type="text" class="swal-usuario__input" id="apellidoMaterno" name="apellidoMaterno" placeholder="Apellido materno">
                            </div>
                            <div class="swal-usuario__field">
                                <label class="swal-usuario__label" for="id_colegio">Colegio</label>
                                <select class="swal-usuario__select" id="id_colegio" name="idColegio">
                                    <option value="">Seleccione Colegio</option>
                                </select>
                            </div>
                            <div class="swal-usuario__field">
                                <label class="swal-usuario__label" for="sexo">Sexo</label>
                                <select class="swal-usuario__select" id="sexo" name="sexo">
                                    <option value="">Seleccione Sexo</option>
                                    <option value="1">Masculino</option>
                                    <option value="2">Femenino</option>
                                </select>
                            </div>
                            <div class="swal-usuario__field">
                                <label class="swal-usuario__label" for="telefono">Telefono</label>
                                <input type="text" class="swal-usuario__input" id="telefono" name="telefono" placeholder="Telefono">
                            </div>
                            <div class="swal-usuario__field">
                                <label class="swal-usuario__label" for="anexo">Anexo</label>
                                <input type="text" class="swal-usuario__input" id="anexo" name="anexo" placeholder="Anexo">
                            </div>
                        </form>
                    </div>
                `,
                showCancelButton: true,
                width: '860px',
                padding: '24px',
                confirmButtonColor: '#0b6aa2',
                cancelButtonColor: '#e9edf3',
                confirmButtonText: 'Guardar cambios',
                cancelButtonText: 'Cancelar',
                customClass: {
                    popup: 'cuerpo_modal_guardar',
                    confirmButton: 'bt_activar_alumno',
                    cancelButton: 'bt_activar_alumno'
                },
                didOpen: () => {
                    const popup = Swal.getPopup();
                    const colegioSelect = popup.querySelector('#id_colegio');
                    const colegioNombre = popup.querySelector('#colegioResumenNombreEditar');
                    const colegioMeta = popup.querySelector('#colegioResumenMetaEditar');
                    const colegioLogo = popup.querySelector('#colegioResumenLogoEditar');
                    const colegioFallback = popup.querySelector('#colegioResumenFallbackEditar');
                    const confirmButton = popup.querySelector('.swal2-confirm');
                    const cancelButton = popup.querySelector('.swal2-cancel');

                    popup.style.borderRadius = '28px';
                    popup.style.boxShadow = '0 28px 60px rgba(20, 42, 82, 0.20)';

                    if (confirmButton) {
                        confirmButton.style.borderRadius = '16px';
                        confirmButton.style.padding = '0.9rem 1.3rem';
                        confirmButton.style.fontWeight = '800';
                    }

                    if (cancelButton) {
                        cancelButton.style.borderRadius = '16px';
                        cancelButton.style.padding = '0.9rem 1.3rem';
                        cancelButton.style.fontWeight = '700';
                        cancelButton.style.color = '#1f2a44';
                    }

                    $('#nombre').val(data.nombre || '');
                    $('#apellidoPaterno').val(data.apellido_paterno || '');
                    $('#apellidoMaterno').val(data.apellido_materno || '');
                    $('#email').val(data.email || '');
                    $('#telefono').val(data.telefono || '');
                    $('#anexo').val(data.anexo || '');
                    $('#sexo').val(data.sexo || '');

                    let optionsHtml = '<option value="">Seleccione Area de Trabajo</option>';
                    (data.areas || []).forEach((area) => {
                        const selected = String(area.id) === String(data.id_area_trabajo) ? ' selected' : '';
                        optionsHtml += `<option value="${area.id}"${selected}>${area.nombre_area}</option>`;
                    });
                    $('#area_trabajo').html(optionsHtml);

                    let colegiosHtml = '<option value="">Seleccione Colegio</option>';
                    (data.colegios || []).forEach((colegio) => {
                        const selected = String(colegio.id) === String(data.id_colegio) ? ' selected' : '';
                        colegiosHtml += `<option value="${colegio.id}"${selected}>${colegio.nombre}</option>`;
                    });
                    $('#id_colegio').html(colegiosHtml);

                    function actualizarResumenColegioEditar() {
                        const opcion = colegioSelect.options[colegioSelect.selectedIndex];
                        const idColegio = opcion ? opcion.value : '';
                        const nombre = opcion ? opcion.text : 'Selecciona un colegio';

                        colegioNombre.textContent = idColegio ? nombre : 'Selecciona un colegio';
                        colegioMeta.textContent = idColegio ? `ID colegio: ${idColegio}` : 'ID colegio: --';
                        colegioFallback.textContent = idColegio || '--';

                        if (idColegio) {
                            colegioLogo.style.display = 'inline-flex';
                            colegioLogo.src = configuracionUrl(`img/colegios/colegio_${idColegio}.png`);
                        } else {
                            colegioLogo.style.display = 'none';
                            colegioFallback.style.display = 'inline-flex';
                        }
                    }

                    actualizarResumenColegioEditar();
                    $(colegioSelect).on('change', actualizarResumenColegioEditar);
                },
                preConfirm: () => {
                    const nombre = document.getElementById('nombre');
                    const apellidoPaterno = document.getElementById('apellidoPaterno');
                    const email = document.getElementById('email');
                    const idColegio = document.getElementById('id_colegio');

                    if (!validarCamposVacios(nombre, apellidoPaterno, email, idColegio)) {
                        Swal.showValidationMessage('Por favor, complete los campos obligatorios en rojo.');
                        return false;
                    }

                    return {
                        action: 'modificarUsuario',
                        userId: userId,
                        nombre: nombre.value,
                        apellidoPaterno: apellidoPaterno.value,
                        apellidoMaterno: document.getElementById('apellidoMaterno').value,
                        email: email.value,
                        telefono: document.getElementById('telefono').value,
                        clave: '',
                        anexo: document.getElementById('anexo').value,
                        areaTrabajo: document.getElementById('area_trabajo').value,
                        sexo: document.getElementById('sexo').value,
                        idColegio: idColegio.value
                    };
                }
            }).then((result) => {
                if (!result.isConfirmed) {
                    return;
                }

                $.ajax({
                    url: configuracionUrl('modelos/guardar/guardar_usuario.php'),
                    type: 'POST',
                    data: result.value,
                    dataType: 'json',
                    success: function (response) {
                        if (!response.success) {
                            Swal.fire('Error', response.message || 'No se pudo guardar los cambios del usuario.', 'error');
                            return;
                        }

                        mostrarConfirmacionConfiguracion('USUARIO ACTUALIZADO', response.message || '', function () {
                            location.reload();
                        });
                    },
                    error: function (xhr, status, error) {
                        console.error('Error al guardar los cambios del usuario:', error);
                        Swal.fire('Error', 'No se pudo guardar los cambios del usuario. Por favor, intente nuevamente.', 'error');
                    }
                });
            });
        },
        error: function (xhr, status, error) {
            console.error('Error al obtener los datos del usuario:', error);
            Swal.fire('Error', 'No se pudo cargar la informacion del usuario. Por favor, intente nuevamente.', 'error');
        }
    });
}

function confirmarReenvioActivacion(userId, email) {
    Swal.fire({
        title: 'Reenviar activacion',
        text: `¿Desea reenviar el correo de activacion de cuenta a ${email}?`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#0d6efd',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Si, reenviar',
        cancelButtonText: 'Cancelar',
        customClass: {
            popup: 'cuerpo_modal_guardar'
        }
    }).then((result) => {
        if (!result.isConfirmed) {
            return;
        }

        $.ajax({
            url: configuracionUrl('modelos/guardar/guardar_usuario.php'),
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'reenviarActivacion',
                userId: userId
            },
            success: function (response) {
                if (!response.success) {
                    Swal.fire('Error', response.message || 'No se pudo reenviar el correo de activacion.', 'error');
                    return;
                }

                mostrarConfirmacionConfiguracion('CORREO REENVIADO', response.message || 'Correo de activacion reenviado correctamente.');
            },
            error: function (xhr, status, error) {
                console.error('Error al reenviar el correo de activacion:', error);
                Swal.fire('Error', 'No se pudo reenviar el correo de activacion. Por favor, intente nuevamente.', 'error');
            }
        });
    });
}