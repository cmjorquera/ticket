<?php
session_start();

require_once __DIR__ . '/../class/conexion.php';
require_once __DIR__ . '/../class/funciones.php';

$funciones = new Funciones();
$idUsuarioSession = htmlspecialchars($_SESSION['id'] ?? '');
$nombre = trim((htmlspecialchars($_SESSION['nombre'] ?? '') . ' ' . htmlspecialchars($_SESSION['apellido_paterno'] ?? '')));
$areaTrabajo = htmlspecialchars($_SESSION['id_area_trabajo'] ?? '');
$idPagActual = '11';

$datosEstados = json_decode($funciones->contarTicketsPorEstado(), true);
$datosCategoriasPayload = json_decode($funciones->contarTicketsPorCategoria(), true);
$datosPorcentajes = json_decode($funciones->obtenerPorcentajeEstadosPorCategoria(), true);
$promediosEstados = json_decode($funciones->obtenerPromedioTiempoEstados(), true);
$usuarios = $funciones->obtenerEstadisticasUsuarios();
$datosMensuales = json_decode($funciones->obtenerDatosGraficoColegios2(), true);

$estados = $datosEstados['estados'] ?? [];
$cantidades = array_map('intval', $datosEstados['cantidades'] ?? []);
$totalTickets = array_sum($cantidades);
$resumenEstados = [];
foreach ($estados as $indice => $estado) {
    $resumenEstados[$estado] = (int) ($cantidades[$indice] ?? 0);
}

$obtenerCuentaEstado = static function (array $resumen, array $terminos): int {
    foreach ($resumen as $nombreEstado => $cantidad) {
        $nombreNormalizado = strtolower((string) $nombreEstado);
        foreach ($terminos as $termino) {
            if (strpos($nombreNormalizado, $termino) !== false) {
                return (int) $cantidad;
            }
        }
    }

    return 0;
};

$ticketsRecibidos = $obtenerCuentaEstado($resumenEstados, ['recib']);
$ticketsAsignados = $obtenerCuentaEstado($resumenEstados, ['asign']);
$ticketsEnProceso = $obtenerCuentaEstado($resumenEstados, ['proceso']);
$ticketsTerminados = $obtenerCuentaEstado($resumenEstados, ['termin']);
$ticketsCerrados = $obtenerCuentaEstado($resumenEstados, ['cerr']);
$ticketsResueltos = $ticketsCerrados > 0 ? $ticketsCerrados : $ticketsTerminados;
$ticketsActivos = max($totalTickets - $ticketsResueltos, 0);
$porcentajeResolucion = $totalTickets > 0 ? round(($ticketsResueltos / $totalTickets) * 100, 1) : 0;

$categorias = $datosCategoriasPayload['datos'] ?? [];
$topCategorias = [];
foreach ($categorias as $nombreCategoria => $estadosCategoria) {
    $totalCategoria = array_sum(array_map('intval', $estadosCategoria));
    $topCategorias[] = [
        'nombre' => $nombreCategoria,
        'total' => $totalCategoria,
        'estados' => $estadosCategoria,
        'porcentajes' => $datosPorcentajes[$nombreCategoria]['estados'] ?? [],
    ];
}
usort($topCategorias, static function (array $a, array $b): int {
    return $b['total'] <=> $a['total'];
});
$topCategorias = array_slice($topCategorias, 0, 6);

$usuariosResumen = [];
foreach ($usuarios as $usuario) {
    $entradas = is_array($usuario['ultimas_entradas'] ?? null) ? count($usuario['ultimas_entradas']) : 0;
    $usuariosResumen[] = [
        'nombre' => $usuario['nombre_completo_usuario'] ?? 'Sin nombre',
        'activo' => !empty($usuario['activo']),
        'tickets_terminados' => (int) ($usuario['tickets_terminados'] ?? 0),
        'tickets_ingresados' => (int) ($usuario['tickets_ingresados'] ?? 0),
        'mensajes' => (int) ($usuario['mensajes'] ?? 0),
        'entradas' => $entradas,
    ];
}
usort($usuariosResumen, static function (array $a, array $b): int {
    $scoreA = $a['tickets_terminados'] + $a['tickets_ingresados'];
    $scoreB = $b['tickets_terminados'] + $b['tickets_ingresados'];

    return $scoreB <=> $scoreA;
});
$usuariosResumen = array_slice($usuariosResumen, 0, 6);

$promediosTarjetas = [
    [
        'clave' => 'recibido_a_asignado',
        'titulo' => 'Recepcion a asignacion',
        'descripcion' => 'Tiempo promedio hasta asignar tecnico',
        'icono' => 'bi-inbox',
        'valor' => (float) ($promediosEstados['recibido_a_asignado'] ?? 0),
    ],
    [
        'clave' => 'asignado_a_en_proceso',
        'titulo' => 'Asignacion a trabajo',
        'descripcion' => 'Inicio operativo del ticket',
        'icono' => 'bi-person-workspace',
        'valor' => (float) ($promediosEstados['asignado_a_en_proceso'] ?? 0),
    ],
    [
        'clave' => 'en_proceso_a_terminado',
        'titulo' => 'Trabajo a termino',
        'descripcion' => 'Resolucion tecnica promedio',
        'icono' => 'bi-tools',
        'valor' => (float) ($promediosEstados['en_proceso_a_terminado'] ?? 0),
    ],
    [
        'clave' => 'terminado_a_cerrado',
        'titulo' => 'Termino a cierre',
        'descripcion' => 'Cierre administrativo del ticket',
        'icono' => 'bi-check2-circle',
        'valor' => (float) ($promediosEstados['terminado_a_cerrado'] ?? 0),
    ],
];

$versionCss = @filemtime(__DIR__ . '/css/estadistica.css') ?: time();
$versionJs = @filemtime(__DIR__ . '/js/estadistica.js') ?: time();

$dashboardData = [
    'estados' => [
        'labels' => array_values($estados),
        'values' => array_values($cantidades),
    ],
    'categorias' => array_map(static function (array $categoria): array {
        return [
            'label' => $categoria['nombre'],
            'total' => $categoria['total'],
        ];
    }, $topCategorias),
    'mensual' => $datosMensuales ?: new stdClass(),
    'ciclo' => array_map(static function (array $item): array {
        return [
            'label' => $item['titulo'],
            'value' => $item['valor'],
        ];
    }, $promediosTarjetas),
];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <base href="../">
    <?php $funciones->header(); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="css/estilo.css" rel="stylesheet">
    <link href="css/bitacora.css" rel="stylesheet">
    <link href="css/contenedor.css" rel="stylesheet">
    <link href="css/tour.css" rel="stylesheet">
    <link href="css/principal.css" rel="stylesheet">
    <link href="estadistica/css/estadistica.css?v=<?php echo $versionCss; ?>" rel="stylesheet">
</head>
<body id="page-top">
    <input type="hidden" id="idUsuario" value="<?php echo htmlspecialchars((string) $idUsuarioSession, ENT_QUOTES, 'UTF-8'); ?>">
    <div id="wrapper">
        <?php $funciones->menuLateral2($idUsuarioSession, $idPagActual); ?>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>
                    <?php $funciones->cabezera(); ?>
                </nav>

            </div>
        </div>
    </div>

    <script>
        window.estadisticaDashboardData = <?php echo json_encode($dashboardData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>;
    </script>
    <script src="js/funciones.js"></script>
    <script src="js/mensajes.js"></script>
    <script src="js/ticket.js"></script>
    <script src="js/buscadores.js"></script>
    <script src="js/validacionTicket.js"></script>
    <script src="js/sb-admin-2.min.js"></script>
    <script src="estadistica/js/estadistica.js?v=<?php echo $versionJs; ?>"></script>
</body>
</html>
