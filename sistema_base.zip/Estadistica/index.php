<?php
require_once __DIR__ . '/../validar_sesion.php';
$pagina_titulo = 'Estadística';
require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-header"><h2>Estadística</h2></div>
<div class="card"><p>Módulo en construcción.</p></div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
